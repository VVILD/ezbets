<html>
<head>
   <style>
   </style>
</head>
<body>

  <IMG src='pChart\examples\x.php'>
</body>
<script>

</script>