<?php

include "conn.php";

$id="123";
$name="dsfds";
$mid="6";
$bid="1";
$bamt="1";

$obj= new bets();
$betObj=$obj->BetReturn(2,1);




?>
